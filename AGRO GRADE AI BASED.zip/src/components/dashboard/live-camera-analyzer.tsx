
"use client"

import { useState, useActionState, useRef, useEffect, useId } from 'react';
import { useFormStatus } from 'react-dom';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { getTomatoRipenessAction, FormStateRipeness } from '@/app/actions';
import { Lightbulb, Loader2, Video, VideoOff, Leaf, Award, Ruler, RefreshCw, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '../ui/button';
import { RipenessBadge, GradeBadge, SizeBadge } from './tomato-ripeness-classifier';
import { Separator } from '../ui/separator';
import { Progress } from '../ui/progress';
import { Alert, AlertTitle, AlertDescription } from '../ui/alert';

const initialState: FormStateRipeness = {
  message: '',
};

function SubmitButton({ hasCameraPermission }: { hasCameraPermission: boolean | null }) {
    const { pending } = useFormStatus();

    const isDisabled = pending || hasCameraPermission !== true;

    return (
        <Button type="submit" disabled={isDisabled} className="w-full">
            {pending ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                </>
            ) : (
                <>
                    <Video className="mr-2 h-4 w-4" />
                    Capture and Analyze Tomato
                </>
            )}
        </Button>
    );
}

export default function LiveCameraAnalyzer() {
  const [formKey, setFormKey] = useState(0);
  const [state, formAction, isPending] = useActionState(getTomatoRipenessAction, initialState);
  const [imageData, setImageData] = useState<string>('');
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const getCameraPermission = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasCameraPermission(false);
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setHasCameraPermission(true);
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Access Denied',
          description: 'Please enable camera permissions in your browser settings.',
        });
      }
    };
    getCameraPermission();

    return () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
        }
    }
  }, [toast]);
  
  const handleFormAction = (formData: FormData) => {
    if (videoRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        const context = canvas.getContext('2d');
        if (context) {
            context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
            const dataUri = canvas.toDataURL('image/jpeg');
            setImageData(dataUri);
            formData.set('imageDataUri', dataUri);
            formAction(formData);
        }
    } else {
        toast({
            variant: "destructive",
            title: "Camera Error",
            description: "Could not capture image from camera.",
        });
    }
  }

  const handleReset = () => {
    setImageData('');
    setFormKey(prevKey => prevKey + 1);
  }
  
  const confidencePercentage = state.ripeness?.confidence ? Math.round(state.ripeness.confidence * 100) : null;
  const tomatoDetected = state.ripeness?.tomatoDetected ?? true;

  const renderResult = () => {
    if (!state.ripeness || isPending) {
        return (
            <div className="p-8 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-center text-muted-foreground min-h-[400px]">
                {isPending ? (
                    <>
                        <Loader2 className="h-12 w-12 mb-4 animate-spin"/>
                        <h3 className="text-lg font-semibold">Analyzing...</h3>
                        <p className="text-sm">Please wait while the AI classifies your tomato.</p>
                    </>
                ) : (
                    <>
                        <Lightbulb className="h-12 w-12 mb-4"/>
                        <h3 className="text-lg font-semibold">Awaiting Analysis</h3>
                        <p className="text-sm">Point your camera at a tomato and click "Capture and Analyze" to see insights here.</p>
                    </>
                )}
            </div>
        )
    }

    if (!tomatoDetected) {
      return (
         <Card>
            <CardHeader className="flex-row items-center justify-between">
                <div>
                    <CardTitle>Analysis Result</CardTitle>
                </div>
                <Button variant="outline" size="icon" onClick={handleReset}>
                    <RefreshCw className="h-4 w-4" />
                    <span className="sr-only">Reset</span>
                </Button>
            </CardHeader>
             <CardContent>
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>No Tomato Detected</AlertTitle>
                    <AlertDescription>
                        {state.ripeness.shortDescription || "The AI could not find a tomato in the captured image. Please try again."}
                    </AlertDescription>
                </Alert>
            </CardContent>
         </Card>
      )
    }
    
    return (
      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
              <CardTitle>Classification Result</CardTitle>
              <CardDescription>The AI has classified the tomato's ripeness, quality, and size.</CardDescription>
          </div>
          <Button variant="outline" size="icon" onClick={handleReset}>
              <RefreshCw className="h-4 w-4" />
              <span className="sr-only">Reset</span>
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
            {state.ripeness.ripenessStage && (
              <div className="space-y-4">
                  <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium flex items-center"><Leaf className="mr-2 h-5 w-5 text-muted-foreground" /> Ripeness Stage:</h3>
                      <RipenessBadge stage={state.ripeness.ripenessStage} />
                  </div>
                  <p className="text-sm text-muted-foreground ml-7">{state.ripeness.shortDescription}</p>
              </div>
            )}
            <Separator />
            {state.ripeness.qualityGrade && (
              <div className="space-y-4">
                  <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium flex items-center"><Award className="mr-2 h-5 w-5 text-muted-foreground" /> Quality Grade:</h3>
                      <GradeBadge grade={state.ripeness.qualityGrade} />
                  </div>
                  {state.ripeness.gradeDescription && <p className="text-sm text-muted-foreground ml-7">{state.ripeness.gradeDescription}</p>}
              </div>
            )}
            <Separator />
            {state.ripeness.sizeClass && (
              <div className="space-y-4">
                  <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium flex items-center"><Ruler className="mr-2 h-5 w-5 text-muted-foreground" /> Size:</h3>
                      <SizeBadge size={state.ripeness.sizeClass} />
                  </div>
                  {state.ripeness.estimatedDiameterInches && <p className="text-sm text-muted-foreground ml-7">Estimated diameter: {state.ripeness.estimatedDiameterInches.toFixed(2)} inches.</p>}
              </div>
            )}

            {confidencePercentage !== null && (
                <>
                <Separator />
                <div className="space-y-2">
                    <Label>Overall Confidence</Label>
                    <Progress value={confidencePercentage} />
                    <p className="text-sm text-right text-muted-foreground">{confidencePercentage}%</p>
                </div>
                </>
            )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-8">
        <form key={formKey} action={handleFormAction}>
            <Card>
                <CardHeader>
                <CardTitle className="font-headline">Live Tomato Analysis</CardTitle>
                <CardDescription>
                    Use your camera to capture an image of a tomato for real-time ripeness, grade, and size classification.
                </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label>Camera Feed</Label>
                        <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center text-muted-foreground relative">
                        <video ref={videoRef} className="w-full aspect-video rounded-md" autoPlay muted playsInline />
                        {hasCameraPermission === false && (
                            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 text-white p-4 rounded-lg">
                                    <VideoOff className="h-10 w-10 mb-2"/>
                                    <p className="text-center font-semibold">Camera access is required.</p>
                                    <p className="text-center text-sm">Please enable camera permissions in your browser settings and refresh the page.</p>
                            </div>
                        )}
                        {hasCameraPermission === null && (
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                                    <Loader2 className="h-10 w-10 animate-spin"/>
                            </div>
                        )}
                        </div>
                    </div>
                </CardContent>
                <CardFooter>
                    <SubmitButton hasCameraPermission={hasCameraPermission} />
                </CardFooter>
            </Card>
      </form>
      
      <div className="space-y-4">
        {renderResult()}
        {imageData && !isPending && (
              <Card>
                <CardHeader>
                  <CardTitle>Last Captured Image</CardTitle>
                </CardHeader>
                <CardContent>
                  <Image src={imageData} alt="Captured for analysis" width={600} height={400} className="rounded-lg border" />
                </CardContent>
              </Card>
        )}
        {state.error && <p className="mt-4 text-sm text-destructive">{state.message}</p>}
      </div>
    </div>
  );
}
