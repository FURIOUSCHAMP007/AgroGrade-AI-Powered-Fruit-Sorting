
'use client';

import { useState, useActionState, useRef, useEffect } from 'react';
import { useFormStatus } from 'react-dom';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { compareImagesAction, FormStateComparison } from '@/app/actions';
import { Lightbulb, Loader2, Video, VideoOff, Camera, Contrast, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import ReactMarkdown from 'react-markdown';

const initialState: FormStateComparison = {
  message: '',
};

function SubmitButton({ disabled }: { disabled: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={disabled || pending} className="w-full">
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Comparing...
        </>
      ) : (
        <>
          <Contrast className="mr-2 h-4 w-4" />
          Compare Images
        </>
      )}
    </Button>
  );
}

export default function LiveComparisonTool() {
  const [state, formAction, isPending] = useActionState(compareImagesAction, initialState);
  const [formKey, setFormKey] = useState(0);

  const [imageDataA, setImageDataA] = useState<string>('');
  const [imageDataB, setImageDataB] = useState<string>('');
  const [fruitType, setFruitType] = useState('Tomato');

  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const getCameraPermission = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasCameraPermission(false);
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setHasCameraPermission(true);
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Access Denied',
          description: 'Please enable camera permissions in your browser settings.',
        });
      }
    };
    getCameraPermission();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [toast]);

  const captureImage = (setter: React.Dispatch<React.SetStateAction<string>>) => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUri = canvas.toDataURL('image/jpeg');
        setter(dataUri);
      }
    } else {
      toast({
        variant: 'destructive',
        title: 'Camera Error',
        description: 'Could not capture image from camera.',
      });
    }
  };

  const handleReset = () => {
    setImageDataA('');
    setImageDataB('');
    setFormKey((prevKey) => prevKey + 1);
  };
  
  const canCompare = imageDataA && imageDataB && fruitType;

  return (
    <div className="grid md:grid-cols-2 gap-8 mt-6">
      <form key={formKey} action={formAction}>
        <Card>
          <CardHeader>
            <CardTitle className="font-headline">Live Comparison</CardTitle>
            <CardDescription>
              Use your camera to capture two images of the same produce type to compare their quality and grading.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             <input type="hidden" name="imageDataUriA" value={imageDataA} />
             <input type="hidden" name="imageDataUriB" value={imageDataB} />
             <input type="hidden" name="fruitType" value={fruitType} />

            <div className="space-y-2">
              <Label>Camera Feed</Label>
              <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center text-muted-foreground relative">
                <video ref={videoRef} className="w-full aspect-video rounded-md" autoPlay muted playsInline />
                {hasCameraPermission === false && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 text-white p-4 rounded-lg">
                    <VideoOff className="h-10 w-10 mb-2" />
                    <p className="text-center font-semibold">Camera access is required.</p>
                  </div>
                )}
                 {hasCameraPermission === null && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                        <Loader2 className="h-10 w-10 animate-spin"/>
                    </div>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Image A</Label>
                <div className="w-full h-32 border rounded-lg flex items-center justify-center bg-muted">
                    {imageDataA ? <Image src={imageDataA} alt="Image A" width={128} height={128} className="rounded-md object-contain h-full w-full" /> : <span className='text-sm text-muted-foreground'>Awaiting capture</span>}
                </div>
                <Button variant="outline" className="w-full" onClick={() => captureImage(setImageDataA)} disabled={hasCameraPermission !== true}>
                    <Camera className="mr-2 h-4 w-4"/> Capture Image A
                </Button>
              </div>
              <div className="space-y-2">
                <Label>Image B</Label>
                <div className="w-full h-32 border rounded-lg flex items-center justify-center bg-muted">
                     {imageDataB ? <Image src={imageDataB} alt="Image B" width={128} height={128} className="rounded-md object-contain h-full w-full" /> : <span className='text-sm text-muted-foreground'>Awaiting capture</span>}
                </div>
                 <Button variant="outline" className="w-full" onClick={() => captureImage(setImageDataB)} disabled={hasCameraPermission !== true}>
                    <Camera className="mr-2 h-4 w-4"/> Capture Image B
                </Button>
              </div>
            </div>

            <div className="space-y-2">
                <Label htmlFor="fruitType">Produce Type</Label>
                <Select name="fruitType" value={fruitType} onValueChange={setFruitType}>
                    <SelectTrigger id="fruitType">
                        <SelectValue placeholder="Select a produce type" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Tomato">Tomato</SelectItem>
                        <SelectItem value="Apple">Apple</SelectItem>
                        <SelectItem value="Banana">Banana</SelectItem>
                        <SelectItem value="Carrot">Carrot</SelectItem>
                        <SelectItem value="Cucumber">Cucumber</SelectItem>
                    </SelectContent>
                </Select>
            </div>
          </CardContent>
          <CardFooter>
            <SubmitButton disabled={!canCompare} />
          </CardFooter>
        </Card>
      </form>

      <div>
        {state.analysis?.comparison && !isPending ? (
          <Card>
            <CardHeader className='flex-row items-center justify-between'>
              <div>
                <CardTitle>Comparison Result</CardTitle>
                <CardDescription>AI analysis of the differences between Image A and Image B.</CardDescription>
              </div>
               <Button variant="outline" size="icon" onClick={handleReset}>
                    <RefreshCw className="h-4 w-4" />
                    <span className="sr-only">Reset</span>
                </Button>
            </CardHeader>
            <CardContent className="prose prose-sm dark:prose-invert">
              <ReactMarkdown>{state.analysis.comparison}</ReactMarkdown>
            </CardContent>
          </Card>
        ) : (
          <div className="p-8 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-center text-muted-foreground h-full">
            {isPending ? (
                 <>
                    <Loader2 className="h-12 w-12 mb-4 animate-spin"/>
                    <h3 className="text-lg font-semibold">Comparing...</h3>
                    <p className="text-sm">Please wait while the AI analyzes the images.</p>
                </>
            ) : (
                <>
                    <Lightbulb className="h-12 w-12 mb-4"/>
                    <h3 className="text-lg font-semibold">Awaiting Comparison</h3>
                    <p className="text-sm">Capture an image for both A and B, then click "Compare Images" to see the analysis.</p>
                </>
            )}
          </div>
        )}
        {state.error && <p className="mt-4 text-sm text-destructive">{state.message}</p>}
      </div>
    </div>
  );
}
