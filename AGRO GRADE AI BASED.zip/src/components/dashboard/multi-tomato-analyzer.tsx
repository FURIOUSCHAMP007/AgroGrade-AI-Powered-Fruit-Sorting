
"use client"

import { useState, useActionState, useEffect } from 'react';
import { useFormStatus } from 'react-dom';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { getMultiTomatoClassificationAction, FormStateMultiRipeness } from '@/app/actions';
import { Upload, Lightbulb, Loader2, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { RipenessBadge, GradeBadge, SizeBadge } from './tomato-ripeness-classifier';

const initialState: FormStateMultiRipeness = {
  message: '',
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
      Classify All Tomatoes
    </Button>
  );
}

export default function MultiTomatoAnalyzer() {
  const [state, formAction, isPending] = useActionState(getMultiTomatoClassificationAction, initialState);
  const { toast } = useToast();

  const [preview, setPreview] = useState<string | null>(null);
  const [imageData, setImageData] = useState<string>('');
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPreview(result);
        setImageData(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const tomatoes = state.ripeness?.tomatoes || [];

  return (
    <div className="grid md:grid-cols-2 gap-8 mt-6">
      <Card>
        <CardHeader>
          <CardTitle className="font-headline">Multi-Tomato Classification</CardTitle>
          <CardDescription>
            Upload an image with multiple tomatoes to get a classification for each one. The AI will detect and analyze every tomato it finds.
          </CardDescription>
        </CardHeader>
        <form action={formAction}>
          <input type="hidden" name="imageDataUri" value={imageData} />
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="picture">Produce Image</Label>
              <div className="w-full aspect-video border-2 border-dashed rounded-lg flex items-center justify-center text-muted-foreground relative">
                {preview ? (
                  <Image src={preview} alt="Image preview" layout="fill" objectFit="contain" className="rounded-lg" />
                ) : (
                  <div className="text-center">
                    <Upload className="mx-auto h-8 w-8" />
                    <p>Click to upload or drag and drop</p>
                  </div>
                )}
                <Input id="picture" type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} accept="image/*" />
              </div>
               {state.fieldErrors?.imageDataUri && <p className="text-sm text-destructive">{state.fieldErrors.imageDataUri[0]}</p>}
            </div>
          </CardContent>
          <CardFooter>
            <SubmitButton />
          </CardFooter>
        </form>
      </Card>
      
      <div>
        {isPending ? (
            <div className="p-8 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-center text-muted-foreground h-full min-h-[300px]">
                <Loader2 className="h-12 w-12 mb-4 animate-spin"/>
                <h3 className="text-lg font-semibold">Analyzing Image...</h3>
                <p className="text-sm">The AI is detecting and classifying all tomatoes.</p>
            </div>
        ) : tomatoes.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>Analysis Complete</CardTitle>
              <CardDescription>
                Found and classified {tomatoes.length} tomato{tomatoes.length > 1 ? 'es' : ''}.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[60vh] overflow-y-auto">
                {tomatoes.map((tomato, index) => (
                    <Card key={index} className="p-4">
                        <CardTitle className="text-lg mb-2">Tomato #{index + 1}</CardTitle>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <span className="text-sm font-medium text-muted-foreground">Ripeness:</span>
                                {tomato.ripenessStage && <RipenessBadge stage={tomato.ripenessStage} />}
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-sm font-medium text-muted-foreground">Quality:</span>
                                {tomato.qualityGrade && <GradeBadge grade={tomato.qualityGrade} />}
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-sm font-medium text-muted-foreground">Size:</span>
                                {tomato.sizeClass && <SizeBadge size={tomato.sizeClass} />}
                            </div>
                             <p className="text-sm text-muted-foreground pt-2">{tomato.description}</p>
                        </div>
                    </Card>
                ))}
            </CardContent>
          </Card>
        ) : (
          <div className="p-8 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-center text-muted-foreground h-full min-h-[300px]">
            <Lightbulb className="h-12 w-12 mb-4"/>
            <h3 className="text-lg font-semibold">Awaiting Analysis</h3>
            <p className="text-sm">Upload an image with tomatoes to get started.</p>
          </div>
        )}
        {state.error && !isPending && (
             <Alert variant="destructive" className="mt-4">
              <AlertTitle>Analysis Error</AlertTitle>
              <AlertDescription>
                {state.message}
              </AlertDescription>
            </Alert>
        )}
      </div>
    </div>
  );
}

