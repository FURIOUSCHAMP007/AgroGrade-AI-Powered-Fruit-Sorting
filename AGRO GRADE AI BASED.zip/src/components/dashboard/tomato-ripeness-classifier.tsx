
"use client"

import * as React from 'react';

export const RipenessBadge = ({ stage }: { stage: string }) => {
    const stageColors: { [key: string]: string } = {
        'Green': 'bg-green-600',
        'Breaker': 'bg-lime-500',
        'Turning': 'bg-yellow-400 text-black',
        'Pink': 'bg-pink-400',
        'Light Red': 'bg-orange-500',
        'Red': 'bg-red-600',
    }
    return (
        <span className={`px-3 py-1 text-sm font-semibold text-white rounded-full ${stageColors[stage] || 'bg-gray-400'}`}>
            {stage}
        </span>
    )
}

export const GradeBadge = ({ grade }: { grade: string }) => {
    const gradeColors: { [key: string]: string } = {
        'U.S. No. 1': 'bg-blue-600',
        'U.S. No. 2': 'bg-sky-500',
        'U.S. No. 3': 'bg-slate-400',
    }
    return (
        <span className={`px-3 py-1 text-sm font-semibold text-white rounded-full ${gradeColors[grade] || 'bg-gray-400'}`}>
            {grade}
        </span>
    )
}

export const SizeBadge = ({ size }: { size: string }) => {
    const sizeColors: { [key: string]: string } = {
        'Small': 'bg-purple-500',
        'Medium': 'bg-indigo-500',
        'Large': 'bg-violet-600',
        'Extra Large': 'bg-fuchsia-700',
    }
    return (
        <span className={`px-3 py-1 text-sm font-semibold text-white rounded-full ${sizeColors[size] || 'bg-gray-400'}`}>
            {size}
        </span>
    )
}
