
import LiveCameraAnalyzer from '@/components/dashboard/live-camera-analyzer';
import ImageComparisonAnalyzer from '@/components/dashboard/image-comparison-analyzer';
import ImageGenerationAnalyzer from '@/components/dashboard/image-generation-analyzer';
import DataCollectionUploader from '@/components/dashboard/data-collection-uploader';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import MultiTomatoAnalyzer from '@/components/dashboard/multi-tomato-analyzer';

export default function AdvisorPage() {
  return (
    <div className="space-y-6">
       <div>
            <h2 className="text-2xl font-bold tracking-tight font-headline">AI Advisor</h2>
            <p className="text-muted-foreground">Get insights on sorting errors and produce quality from our AI analysis tools.</p>
        </div>

        <Tabs defaultValue="classification">
            <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 h-auto">
                <TabsTrigger value="classification">Tomato Classification</TabsTrigger>
                <TabsTrigger value="multi-tomato">Multi-Tomato</TabsTrigger>
                <TabsTrigger value="comparison">Grading Comparison</TabsTrigger>
                <TabsTrigger value="labeling">Data Labeling</TabsTrigger>
                <TabsTrigger value="generation">Image Generation</TabsTrigger>
            </TabsList>
            <TabsContent value="classification" className="mt-6">
                <LiveCameraAnalyzer />
            </TabsContent>
            <TabsContent value="multi-tomato" className="mt-6">
                <MultiTomatoAnalyzer />
            </TabsContent>
            <TabsContent value="comparison" className="mt-6">
                <ImageComparisonAnalyzer />
            </TabsContent>
            <TabsContent value="labeling" className="mt-6">
                <DataCollectionUploader />
            </TabsContent>
            <TabsContent value="generation" className="mt-6">
                <ImageGenerationAnalyzer />
            </TabsContent>
        </Tabs>
    </div>
  );
}
