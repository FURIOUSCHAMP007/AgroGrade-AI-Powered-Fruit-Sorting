
'use server';

/**
 * @fileOverview This flow provides an AI-powered tomato ripeness and quality classification.
 *
 * - getTomatoRipeness - Analyzes an image of a tomato and determines its ripeness stage and quality grade.
 * - GetTomatoRipenessInput - The input type for the getTomatoRipeness function.
 * - GetTomatoRipenessOutput - The return type for the getTomatoRipeness function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GetTomatoRipenessInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of a single tomato, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GetTomatoRipenessInput = z.infer<
  typeof GetTomatoRipenessInputSchema
>;

const GetTomatoRipenessOutputSchema = z.object({
  tomatoDetected: z.boolean().describe('Whether a tomato was detected in the image.'),
  ripenessStage: z
    .enum(['Green', 'Breaker', 'Turning', 'Pink', 'Light Red', 'Red'])
    .optional()
    .describe(
      'The determined ripeness stage of the tomato based on USDA standards.'
    ),
  qualityGrade: z
    .enum(['U.S. No. 1', 'U.S. No. 2', 'U.S. No. 3'])
    .optional()
    .describe('The quality grade of the tomato based on USDA standards for defects.'),
  sizeClass: z
    .enum(['Small', 'Medium', 'Large', 'Extra Large'])
    .optional()
    .describe('The size classification of the tomato based on its diameter.'),
  estimatedDiameterInches: z
    .number()
    .optional()
    .describe('The estimated diameter of the tomato in inches.'),
  shortDescription: z
    .string()
    .describe('A brief, one-sentence description of the ripeness stage, or a reason if no tomato is detected.'),
  gradeDescription: z
    .string()
    .optional()
    .describe('A brief, one-sentence description of the quality grade and any observed defects.'),
  confidence: z
    .number()
    .min(0)
    .max(1)
    .describe(
      'A confidence score between 0 and 1 representing how certain the model is about the overall assessment.'
    ),
});
export type GetTomatoRipenessOutput = z.infer<
  typeof GetTomatoRipenessOutputSchema
>;

export async function getTomatoRipeness(
  input: GetTomatoRipenessInput
): Promise<GetTomatoRipenessOutput> {
  return getTomatoRipenessFlow(input);
}

const getTomatoRipenessPrompt = ai.definePrompt({
  name: 'getTomatoRipenessPrompt',
  input: {schema: GetTomatoRipenessInputSchema},
  output: {schema: GetTomatoRipenessOutputSchema},
  prompt: `You are an expert in agriculture, specializing in tomato grading and ripeness classification based on USDA standards. You are also excellent at estimating object sizes from images.

Analyze the provided image. First, determine if a single, clear tomato is visible.

**Input Image:**
{{media url=imageDataUri}}

**Your Task:**
1.  **Detect Tomato:** Is there a tomato in the image?
    *   **If NO:** Set \`tomatoDetected\` to \`false\`. Set \`shortDescription\` to a brief explanation (e.g., "No tomato was found in the image." or "The image is too blurry to analyze."). Provide a confidence score of 0. Do not fill out any other fields.
    *   **If YES:** Set \`tomatoDetected\` to \`true\` and proceed with the steps below.

2.  **Classify Ripeness:** Determine the **ripeness stage** from the six stages listed below.
3.  **Classify Quality:** Determine the **quality grade** by assessing its shape, color, and any visible defects (cracks, blemishes, rot, etc.).
4.  **Estimate Size:** Estimate the **diameter** of the tomato in inches and classify it into a **size class**.
5.  **Provide Descriptions:** Write a one-sentence description for the ripeness stage and another for the quality grade, mentioning any observed defects.
6.  **Provide Confidence:** Provide a single confidence score (0.0 to 1.0) for your overall assessment.

**Ripeness Stages (USDA):**
- **Green:** The entire surface of the tomato is green.
- **Breaker:** There is a definite break in color from green to tannish-yellow, pink, or red on not more than 10% of the surface.
- **Turning:** More than 10% but not more than 30% of the surface shows a definite change in color.
- **Pink:** More than 30% but not more than 60% of the surface shows pink or red color.
- **Light Red:** More than 60% but not more than 90% of the surface is pinkish-red or red.
- **Red:** More than 90% of the surface is red.

**Quality Grades (USDA Standards for Fresh Tomatoes):**
- **U.S. No. 1:** Well-formed, clean, smooth, and free from decay, sunscald, and damage or serious damage from any cause.
- **U.S. No. 2:** Fairly well-formed, not seriously misshapen, and free from decay and serious damage.
- **U.S. No. 3:** May be misshapen, has defects that are serious but not very serious. Free from decay.

**Size Classification (based on diameter):**
- **Small:** Less than 2.25 inches
- **Medium:** 2.25 to 2.5 inches
- **Large:** 2.5 to 3.0 inches
- **Extra Large:** 3.0 inches and up

Return all fields in the specified output format.
`,
});

const getTomatoRipenessFlow = ai.defineFlow(
  {
    name: 'getTomatoRipenessFlow',
    inputSchema: GetTomatoRipenessInputSchema,
    outputSchema: GetTomatoRipenessOutputSchema,
  },
  async input => {
    const {output} = await getTomatoRipenessPrompt(input);
    return output!;
  }
);
