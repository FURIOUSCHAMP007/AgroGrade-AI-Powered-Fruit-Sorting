
'use server';

/**
 * @fileOverview This flow provides an AI-powered classification for multiple tomatoes in a single image.
 *
 * - getMultiTomatoClassification - Analyzes an image and identifies all tomatoes, determining the ripeness stage, quality grade, and size for each.
 * - GetMultiTomatoClassificationInput - The input type for the getMultiTomatoClassification function.
 * - GetMultiTomatoClassificationOutput - The return type for the getMultiTomatoClassification function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GetMultiTomatoClassificationInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of multiple tomatoes, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GetMultiTomatoClassificationInput = z.infer<
  typeof GetMultiTomatoClassificationInputSchema
>;

const TomatoClassificationSchema = z.object({
  ripenessStage: z
    .enum(['Green', 'Breaker', 'Turning', 'Pink', 'Light Red', 'Red'])
    .describe(
      'The determined ripeness stage of the tomato based on USDA standards.'
    ),
  qualityGrade: z
    .enum(['U.S. No. 1', 'U.S. No. 2', 'U.S. No. 3'])
    .describe('The quality grade of the tomato based on USDA standards for defects.'),
  sizeClass: z
    .enum(['Small', 'Medium', 'Large', 'Extra Large'])
    .describe('The size classification of the tomato based on its diameter.'),
  description: z
    .string()
    .describe('A brief, one-sentence description of the tomato\'s ripeness, grade, and any observed defects.'),
});

const GetMultiTomatoClassificationOutputSchema = z.object({
    tomatoes: z.array(TomatoClassificationSchema).describe('An array of classifications for each tomato detected in the image.')
});
export type GetMultiTomatoClassificationOutput = z.infer<
  typeof GetMultiTomatoClassificationOutputSchema
>;

export async function getMultiTomatoClassification(
  input: GetMultiTomatoClassificationInput
): Promise<GetMultiTomatoClassificationOutput> {
  return getMultiTomatoClassificationFlow(input);
}

const getMultiTomatoClassificationPrompt = ai.definePrompt({
  name: 'getMultiTomatoClassificationPrompt',
  input: {schema: GetMultiTomatoClassificationInputSchema},
  output: {schema: GetMultiTomatoClassificationOutputSchema},
  prompt: `You are an expert in agriculture, specializing in tomato grading and ripeness classification based on USDA standards.

Analyze the provided image containing one or more tomatoes. For each tomato you identify, you must classify its ripeness, quality, and size.

**Input Image:**
{{media url=imageDataUri}}

**Your Task:**
1.  **Detect all Tomatoes:** Identify every individual tomato in the image.
2.  **Classify Each Tomato:** For each detected tomato, perform the following classifications based on USDA standards.
    *   **Ripeness Stage:** Determine the ripeness stage from the six stages listed below.
    *   **Quality Grade:** Determine the quality grade by assessing its shape, color, and any visible defects (cracks, blemishes, rot, etc.).
    *   **Size Class:** Estimate the size and assign a size classification.
    *   **Description:** Provide a one-sentence summary for each tomato, covering its ripeness and quality.
3.  **Return an Array:** Compile the results into an array, where each object represents a single classified tomato. If no tomatoes are found, return an empty array.

**Ripeness Stages (USDA):**
- **Green:** The entire surface is green.
- **Breaker:** A definite break in color from green on not more than 10% of the surface.
- **Turning:** More than 10% but not more than 30% of the surface shows a color change.
- **Pink:** More than 30% but not more than 60% of the surface shows pink or red.
- **Light Red:** More than 60% but not more than 90% of the surface is red.
- **Red:** More than 90% of the surface is red.

**Quality Grades (USDA):**
- **U.S. No. 1:** Well-formed, clean, and free from decay and serious damage.
- **U.S. No. 2:** Not seriously misshapen, free from decay and serious damage.
- **U.S. No. 3:** May be misshapen, has defects, but is free from decay.

**Size Classification (based on diameter):**
- **Small:** Less than 2.25 inches
- **Medium:** 2.25 to 2.5 inches
- **Large:** 2.5 to 3.0 inches
- **Extra Large:** 3.0 inches and up

Return a JSON object containing a 'tomatoes' array with the classification for each detected tomato.
`,
});

const getMultiTomatoClassificationFlow = ai.defineFlow(
  {
    name: 'getMultiTomatoClassificationFlow',
    inputSchema: GetMultiTomatoClassificationInputSchema,
    outputSchema: GetMultiTomatoClassificationOutputSchema,
  },
  async input => {
    const {output} = await getMultiTomatoClassificationPrompt(input);
    return output!;
  }
);
