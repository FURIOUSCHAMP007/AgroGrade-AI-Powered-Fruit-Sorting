
'use server';

/**
 * @fileOverview This flow provides image analysis advice for sorting sessions with above-average error rates.
 *
 * - analyzeImageForSortingErrors - Analyzes images of incorrectly classified fruit to identify potential issues.
 * - AnalyzeImageForSortingErrorsInput - The input type for the analyzeImageForSortingErrors function.
 * - AnalyzeImageForSortingErrorsOutput - The return type for the analyzeImageForSortingErrors function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeImageForSortingErrorsInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of incorrectly classified fruit, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  fruitType: z.string().describe('The type of fruit in the image (e.g., tomato, apple).'),
});
export type AnalyzeImageForSortingErrorsInput = z.infer<
  typeof AnalyzeImageForSortingErrorsInputSchema
>;

const AnalyzeImageForSortingErrorsOutputSchema = z.object({
  analysis: z
    .string()
    .describe(
      'A detailed analysis of the produce in the image, including its likely classification and any visual defects or quality issues. Use markdown for lists.'
    ),
  confidence: z
    .number()
    .describe(
      'A confidence score between 0.0 and 1.0 representing how certain you are about the analysis.'
    ),
});
export type AnalyzeImageForSortingErrorsOutput = z.infer<
  typeof AnalyzeImageForSortingErrorsOutputSchema
>;

export async function analyzeImageForSortingErrors(
  input: AnalyzeImageForSortingErrorsInput
): Promise<AnalyzeImageForSortingErrorsOutput> {
  return analyzeImageForSortingErrorsFlow(input);
}

const analyzeImageForSortingErrorsPrompt = ai.definePrompt({
  name: 'analyzeImageForSortingErrorsPrompt',
  input: {schema: AnalyzeImageForSortingErrorsInputSchema},
  output: {schema: AnalyzeImageForSortingErrorsOutputSchema},
  prompt: `You are an expert agricultural inspector. Analyze the image of the {{{fruitType}}} and provide a quality assessment.

**Image:** {{media url=imageDataUri}}

**Your Task:**
Provide a clear, concise analysis in a markdown bulleted list. Your analysis should cover:
1.  **Identification:** Confirm if the item matches the 'Expected Produce Type'. If not, state the discrepancy.
2.  **Classification:** State the most likely quality classification (e.g., Ripe, Grade B, Spoiled).
3.  **Visual Evidence:** Justify your classification by describing color, shape, and any visible blemishes or defects.

Do not add a summary sentence.
`,
});

const analyzeImageForSortingErrorsFlow = ai.defineFlow(
  {
    name: 'analyzeImageForSortingErrorsFlow',
    inputSchema: AnalyzeImageForSortingErrorsInputSchema,
    outputSchema: AnalyzeImageForSortingErrorsOutputSchema,
  },
  async input => {
    const {output} = await analyzeImageForSortingErrorsPrompt(input);
    return output!;
  }
);
