
'use server';

/**
 * @fileOverview This flow compares two images of the same produce type to provide a grading analysis.
 *
 * - compareProduceForGrading - Compares two images and details the differences for grading.
 * - CompareProduceForGradingInput - The input type for the compareProduceForGrading function.
 * - CompareProduceForGradingOutput - The return type for the compareProduceForGrading function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CompareProduceForGradingInputSchema = z.object({
  imageDataUriA: z
    .string()
    .describe(
      "The first image of the produce, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  imageDataUriB: z
    .string()
    .describe(
      "The second image of the produce, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  fruitType: z.string().describe('The type of produce in the images (e.g., tomato, apple).'),
});
export type CompareProduceForGradingInput = z.infer<
  typeof CompareProduceForGradingInputSchema
>;

const CompareProduceForGradingOutputSchema = z.object({
  comparison: z
    .string()
    .describe(
      'A detailed analysis comparing the two images, explaining the visual differences that justify their respective classifications. Use markdown for lists.'
    ),
});
export type CompareProduceForGradingOutput = z.infer<
  typeof CompareProduceForGradingOutputSchema
>;

export async function compareProduceForGrading(
  input: CompareProduceForGradingInput
): Promise<CompareProduceForGradingOutput> {
  return compareProduceForGradingFlow(input);
}

const compareProduceForGradingPrompt = ai.definePrompt({
  name: 'compareProduceForGradingPrompt',
  input: {schema: CompareProduceForGradingInputSchema},
  output: {schema: CompareProduceForGradingOutputSchema},
  prompt: `You are an expert agricultural inspector. Your task is to compare two images of a {{{fruitType}}} and describe the visual differences in a markdown bulleted list.

**Image A:**
{{media url=imageDataUriA}}

**Image B:**
{{media url=imageDataUriB}}

**Your Task:**
Directly compare the two images and provide a summary of their differences. Focus on these criteria:
*   **Color:** Note any differences in hue, uniformity, or vibrancy.
*   **Size & Shape:** Compare their relative size and note any deformities.
*   **Blemishes & Defects:** Identify specific defects like spots, cracks, or bruises in one image versus the other.
*   **Overall Quality:** Briefly conclude which item appears to be of higher quality based on the visual evidence.

Do not include a summary sentence. Structure your entire output as a markdown bulleted list.
`,
});

const compareProduceForGradingFlow = ai.defineFlow(
  {
    name: 'compareProduceForGradingFlow',
    inputSchema: CompareProduceForGradingInputSchema,
    outputSchema: CompareProduceForGradingOutputSchema,
  },
  async input => {
    const {output} = await compareProduceForGradingPrompt(input);
    return output!;
  }
);
